
/*
Author: Dustin Lloyd A01360009
*/

const $imageWindow          = $('#view-product-window');
const $BtnMenu              = $('#btn-menu');
const $siteNav              = $('nav');
const popUp                 = document.querySelector('article');
const popUp2                = document.querySelector('congrats');
const startBtn              = document.querySelector('#start-btn');
const stopBtn               = document.querySelector('#stop-btn');
const reverseBtn            = document.querySelector('#reverse-btn');
const popUpBack             = document.querySelector('#popup-01');
const delay                 = 1000;
const heading               = document.querySelector('h2');
heading.classList.add('some-gd-decor');
const popUpBtn               = document.querySelector('#popup-btn');
const popUpBtnOut            = document.querySelector('#popup-btn-output');
const popUpBtn2              = document.querySelector('#popup-btn2');
const popUpBtnOut2           = document.querySelector('#popup-btn-output2');
let positionStart            = 0;
const positionEnd            = 15;
heading.style.position       = 'relative';
let currentImage             = 1;
let currentImage2            = 1;
let currentImage3            = 1;
let currentImage4            = 1;
let currentImage5            = 1;
//let position = 0;
let position2                = 30;
let position3                = 60;
let moveRight                = true;
let moveRight2               = true;
let moveRight3               = true;
let moveRight4               = true;
let moveRight5               = true;
const intervalInMilliseconds = 20;
const die                    =document.querySelector('#die01');
const die2                   =document.querySelector('#die02');
const die3                   =document.querySelector('#die03');
const die4                   =document.querySelector('#die04');
const die5                   =document.querySelector('#die05');
const die6                   =document.querySelector('#die06');
const output                 =document.querySelector('#output');
const output2                =document.querySelector('#output2');
let dieRollNum = 0;
let opponentTurn = false;
const opponent               =document.querySelector('#player2');
const player                 =document.querySelector('#player1');
const diceBoard              =document.querySelector('#dice-board');
const scorecard              =document.querySelector('#form');
const scorecardIcon          =document.querySelector('#icon');
const scorecard2             =document.querySelector('#form2');
const scorecardIcon2         =document.querySelector('#icon2');
const round                  =document.querySelector('#round');
const aces                   =document.querySelector('#aces');
const twos                   =document.querySelector('#twos');
const threes                 =document.querySelector('#threes');
const fours                  =document.querySelector('#fours');
const fives                  =document.querySelector('#fives');
const sixes                  =document.querySelector('#sixes');
const threeOfaKind           =document.querySelector('#three-of-a-kind');
const fourOfaKind            =document.querySelector('#four-of-a-kind');
const fullHouse              =document.querySelector('#full-house');
const smallStraight          =document.querySelector('#sm-straight');
const largeStraight          =document.querySelector('#lf-straight');
const yahtzee                =document.querySelector('#yahtzee');
const aces2                  =document.querySelector('#aces2');
const twos2                  =document.querySelector('#twos2');
const threes2                =document.querySelector('#threes2');
const fours2                 =document.querySelector('#fours2');
const fives2                 =document.querySelector('#fives2');
const sixes2                 =document.querySelector('#sixes2');
const threeOfaKind2          =document.querySelector('#three-of-a-kind2');
const fourOfaKind2           =document.querySelector('#four-of-a-kind2');
const fullHouse2             =document.querySelector('#full-house2');
const smallStraight2         =document.querySelector('#sm-straight2');
const largeStraight2         =document.querySelector('#lf-straight2');
const yahtzee2               =document.querySelector('#yahtzee2');
let points = [];
const displayTotal           =document.querySelector('#display-total');
const displayTotal2          =document.querySelector('#display-total2');


player.classList.toggle("visible");
player.classList.toggle("invisible");

$BtnMenu.click( function(){
    $siteNav.toggleClass('show');
    if($BtnMenu.html() == ("☰")){
        $BtnMenu.html("✕");
    }else{
        $BtnMenu.html("☰");
    }
});
let masterArray      =[];
let index=0;
let index2=0;
let masterEnemyArray =[];
let show             =false;
let show2            =false;

////Universal Things////

function change(){
        stopBtn.addEventListener('click', endsturn );
};

startBtn.addEventListener('click', function(){
    index++;
    if( index===1){
        $(`#dice-board`).attr('src', `images/diceboard-roll1.png`);
    }
    if( index===2){
        $(`#dice-board`).attr('src', `images/diceboard-roll2.png`);
    }
    if( index===3){
        $(`#dice-board`).attr('src', `images/diceboard-roll3.png`);
    }
    if (index >3){
        startBtn.removeEventListener('click', startSpin);
        startBtn.removeEventListener('click', startRoll);
        startBtn.removeEventListener('click', startSpin2);
        startBtn.removeEventListener('click', startRoll2);
        startBtn.removeEventListener('click', startSpin3);
        startBtn.removeEventListener('click', startRoll3);
        startBtn.removeEventListener('click', startSpin4);
        startBtn.removeEventListener('click', startRoll4);
        startBtn.removeEventListener('click', startSpin5);
        startBtn.removeEventListener('click', startRoll5);
        stopBtn.addEventListener('click', endsturn );
        console.log(playerOne.masterArray.indexOf(6) > -1);
        console.log(playerOne.masterArray.indexOf(5) > -1);
        console.log(playerOne.masterArray.indexOf(4) > -1);
        console.log(playerOne.masterArray.indexOf(3) > -1);
        console.log(playerOne.masterArray.indexOf(2) > -1);
        console.log(playerOne.masterArray.indexOf(1) > -1);
    }
});
function winnerWinnerChickenDinner(){
    if(playerOneScore > playerTwoScore){
        popUpBtnOut2.innerHTML = 'You WIN! close the window to play again';
    }else if(playerOneScore < playerTwoScore){
        popUpBtnOut2.innerHTML = 'You Lose. close the window to play again';
    }else{
        popUpBtnOut2.innerHTML = 'its a Tie! Play again? close the window!';
    }
        popUp2.classList.toggle('show-02');
        popUpBtn2.addEventListener("click", function(){
        popUp2.classList.remove('show-02');
        popUp2.classList.toggle('show-02');
        popUp2.classList.toggle('show-02');
    });
};
function endsturn (){
    if(opponentTurn === false){
        console.log(`${playerOne.sorting()}`);
        scorecardIcon.click();
        $('#aces, #twos, #threes, #fours, #fives, #sixes, #full-house, #lg-straight, #sm-straight, #four-of-a-kind, #three-of-a-kind, #yahtzee, #chance').prop("disabled", false);
        opponentTurn = true;
        player.classList.toggle("visible");
        player.classList.toggle("invisible");
        opponent.classList.toggle("visible");
        opponent.classList.toggle("invisible");
        index=0;

    }
    else{
        index2++;
        round.innerHTML = (`${index2}`);
        scorecardIcon2.click();
        $('#aces2, #twos2, #threes2, #fours2, #fives2, #sixes2, #full-house2, #lg-straight2, #sm-straight2, #four-of-a-kind2, #three-of-a-kind2, #yahtzee2, #chance2').prop("disabled", false);
        opponentTurn = false;
        player.classList.toggle("visible");
        player.classList.toggle("invisible");
        opponent.classList.toggle("visible");
        opponent.classList.toggle("invisible");
        index=0;
        if(index2 >=13){
            winnerWinnerChickenDinner();
            playerOneScore =0;
            playerTwoScore =0;
        }
    }
    stopBtn.removeEventListener('click', endsturn );
    startBtn.addEventListener('click', startSpin);
    startBtn.addEventListener('click', startRoll);
    startBtn.addEventListener('click', startSpin2);
    startBtn.addEventListener('click', startRoll2);
    startBtn.addEventListener('click', startSpin3);
    startBtn.addEventListener('click', startRoll3);
    startBtn.addEventListener('click', startSpin4);
    startBtn.addEventListener('click', startRoll4);
    startBtn.addEventListener('click', startSpin5);
    startBtn.addEventListener('click', startRoll5);
};
scorecardIcon.addEventListener('click', function(){
    if(show === false){
        show = true;
        $(`#icon`).attr('src', `images/hide-scorecard.png`);
        scorecard.classList.toggle("visible");
        scorecard.classList.toggle("invisible");
    }else{
        show=false;
        $(`#icon`).attr('src', `images/show-scorecard.png`);
        scorecard.classList.toggle("visible");
        scorecard.classList.toggle("invisible");
    }
    });
    scorecardIcon2.addEventListener('click', function(){
        if(show2 === false){
            show2 = true;
            $(`#icon2`).attr('src', `images/hide-scorecard-opponent.png`);
            scorecard2.classList.toggle("visible");
            scorecard2.classList.toggle("invisible");
        }else{
            show2=false;
            $(`#icon2`).attr('src', `images/show-scorecard-opponent.png`);
            scorecard2.classList.toggle("visible");
            scorecard2.classList.toggle("invisible");
        }
        });
let timeoutHandlerx;


    timeoutHandlerx = setTimeout(function(){
        popUp.classList.toggle('show-02');
        popUpBtnOut.innerHTML = "<p>The game consists of 13 rounds, and the player with the highest score Wins. In each round, the player rolls 5 dice and can re-roll up to 3 times. The player scores the dice in one of 13 categories, each with a different rule. The player must score once in each category, and cannot change the score once recorded. A Yahtzee is a 5-of-a-kind and scores 50 points. Multiple Yahtzees can score extra points.</p><br></br><p>The hands are classic poker hands, and can be seen by clicking on the score card in the left and right corner shields. The totals will be Tallied there. If you want to add a dice to your hand click on it and it will jump to your hand. You have three rolls (tracked upper left), and thirteen rounds( tracked upper right). Roll wisely....</p><br></br><p>My apologies for not finishing the opponent Ai. I really tried, but the finite state machine Im making to track everything got out of control. I WILL FINISH IT IF ITS THE LAST THING I DO! :)</p>"
    }, delay);

startBtn.addEventListener("click", function() {
    clearTimeout(timeoutHandlerx);
    popUp.classList.toggle('show-02');
    popUp.classList.toggle('show-02');
});

popUpBtn.addEventListener("click", function() {
    popUp.classList.remove('show-02');
    popUp.classList.toggle('show-02');
    popUp.classList.toggle('show-02');
});


let rollHandler;

let animationDiceHandler;

startBtn.addEventListener('click', startSpin);
startBtn.addEventListener('click', startRoll);

function startRoll(){
    rollHandler = requestAnimationFrame( roll );
    startBtn.removeEventListener('click', startRoll );
};

function startSpin(){
    animationDiceHandler = requestAnimationFrame( rotateYoYoMa );
    startBtn.removeEventListener('click', startSpin );
    d=0.5;
}

let timeoutHandler;
let reverse = false;
let d =0.5;
function rotateYoYoMa(){
    let element = `01`;
    if(reverse === false){
        currentImage++;
        d+=2;
        if(currentImage >249){
            currentImage = 1;
        }
    $(`#die${element}`).attr('src', `images/rolling-die/dice_animation_${currentImage}.png`);
    }else if(reverse === true){
        currentImage--;
        d+=2;
        if(currentImage < 1){
            currentImage = 250;
            }
    $(`#die${element}]`).attr('src', `images/rolling-die/dice_animation_${currentImage}.png`);
        }
    timeoutHandler = setTimeout(function(){
        animationDiceHandler = requestAnimationFrame( rotateYoYoMa );
    },0.01*d);
}

///////////  Maybe adding my dice object array here

 let die_01 = {
    pos: [ 0, 0 ],
    vel: [ 4, 5 ],
    startPos: [ 0, 0 ],
    range: 100,
    element: `01`
    }
let die_02 = { 
    pos: [ 0, 0 ],
    vel: [ 2, 6 ],
    startPos: [ 0, 0 ],
    range:90,
    element: `02`
  }
let die_03 = {
    pos: [ 0, 0 ],
    vel: [ 6, 4 ],
    startPos: [ 0, 0 ],
    range: 240,
    element: `03`
  }
let die_04 = {
    pos: [ 0, 0 ],
    vel: [ 3, 4 ],
    startPos: [ 0, 0 ],
    range: 240,
    element: `04`
  }
let die_05 = {
    pos: [ 0, 0 ],
    vel: [ 4, 4 ],
    startPos: [ 0, 0 ],
    range: 100,
    element: `05`
  }


////Die One Start/////

let reset = () => {


    die.style.position =`absolute`;
    die.style.top = `0%`;
    die.style.left = `0%`;
    die.style.width.left = `5%`;
    die.style.height = `auto`;
    die.style.transform = 'none';
    moveRight= true;
    $(die).attr('src', `images/rolling-die/dice_animation_1.png`);
    startBtn.addEventListener('click', startRoll);
    startBtn.addEventListener('click', startSpin );
    die_01.pos = [ 0, 0 ];
    die_01.vel = [ 4, 5 ];
  };

let returnImage;

let timeoutHandler1;
function roll(){
    let dMs = 300;
    let dst = dMs * 0.001;
    let vMagT = Math.hypot(die_01.vel[0], die_01.vel[1]);
    let dx = die_01.pos[0] - die_01.startPos[0];
    let dy = die_01.pos[1] - die_01.startPos[1];
    let rangeRemainder = die_01.range - Math.hypot(dx, dy);
    let veloC = 1 - Math.max(0, Math.min(1, dst * vMagT / rangeRemainder));
    if(moveRight === true){ 
        die_01.vel[0] *= veloC;
        die_01.vel[1] *= veloC;
        die_01.pos[0] += (die_01.vel[0] * dst);
        die_01.pos[1] += (die_01.vel[1] * dst);
        if(die_01.pos[0] > 60){
            moveRight = false;
            die.style.transform = 'scaleX(-1)';
        }
        die.style.left = `${die_01.pos[0]}%`;
        die.style.top = `${die_01.pos[1]}%`;
    }else if(moveRight === false){ 
        die_01.vel[0] *= veloC;
        die_01.vel[1] *= veloC;
        die_01.pos[0] = die_01.pos[0]+ die_01.vel[0] * dst;
        die_01.pos[1] = die_01.pos[1]- die_01.vel[1] * dst *1.5;
        if(die_01.pos[0] <= 25){
            moveRight = true;
            die.style.transform = 'scaleX(1)';
        }
        die.style.left = `${die_01.pos[0]}%`;
        die.style.top = `${die_01.pos[1]}%`;
    }
    timeoutHandler1 = setTimeout(function(){
    rollHandler = requestAnimationFrame( roll );
    if (moveRight === false && die_01.pos[0] > 62){
    //if (moveRight === false && die_01.pos[0] < 57){//add in vMagT
        let element= die_01.element;
        cancelAnimationFrame(rollHandler);
        cancelAnimationFrame( animationDiceHandler );
        clearTimeout( timeoutHandler);
        clearTimeout( timeoutHandler1);
        let theDie = new Dice();
        theDie.shake();
        returnImage = theDie.result();
        if(opponentTurn === true){
            playerTwo.addDieToHand(returnImage);
        }else{
        playerOne.addDieToHand(returnImage);
        }
        $(`#die${element}`).attr('src', `images/final-die/${returnImage}.png`);
    }
    });
}

//////
reverseBtn.addEventListener('click', function(){
    if(opponentTurn ===false && die.style.top != `60%`){
        playerOne.returnDieToCup();
        die_01.pos = [ 0, 0 ];
        die_01.vel = [ 4, 5 ];
        die_01.startPos = [ 0, 0 ];
        die_01.range = 100;
        die.style.left = `${die_01.pos[0]}%`;
        die.style.top = `${die_01.pos[1]}%`;
        reset();
    }else if(opponentTurn === true && die.style.top != `17%`){
        playerTwo.returnDieToCup();
        die_01.pos = [ 0, 0 ];
        die_01.vel = [ 4, 5 ];
        die_01.startPos = [ 0, 0 ];
        die_01.range = 100;
        die.style.left = `${die_01.pos[0]}%`;
        die.style.top = `${die_01.pos[1]}%`;
        reset();
    }
    
});

die.addEventListener('click', function(){
    if(opponentTurn === false&& die.style.top != `60%`){
        die_01.pos = [ 0, 0 ];
        die_01.vel = [ 4, 5 ];
        die_01.startPos = [ 0, 0 ];
        die_01.range = 100;
        die.style.left = `6.5%`;
        die.style.top = `60%`;
        playerOne.addDieToKeep(returnImage);
        playerOne.filterTheFilth(returnImage);
        if(masterArray.length < 6){
        masterArray.push(die);
        }
        if (playerOne.masterArray.length === 5){
            change();
        }
    }
    else if(opponentTurn === true && die.style.top != `17%`){
        die_01.pos = [ 0, 0 ];
        die_01.vel = [ 4, 5 ];
        die_01.startPos = [ 0, 0 ];
        die_01.range = 100;
        die.style.left = `54%`;
        die.style.top = `17%`;
        playerTwo.addDieToKeep(returnImage);
        playerTwo.filterTheFilth(returnImage);
        if(masterEnemyArray.length < 6){
        masterEnemyArray.push(die);
        }
        if (playerTwo.masterArray.length === 5){
            change();
        }
    startBtn.removeEventListener('click', startRoll );
    startBtn.removeEventListener('click', startSpin );
    }  
});

//// Start DIE2///

let rollHandler2;

let animationDiceHandler2;

startBtn.addEventListener('click', startSpin2);
startBtn.addEventListener('click', startRoll2);

function startRoll2(){
    rollHandler2 = requestAnimationFrame( roll2 );
    startBtn.removeEventListener('click', startRoll2 );
};

function startSpin2(){
    animationDiceHandler2 = requestAnimationFrame( rotateYoYoMa2 );
    startBtn.removeEventListener('click', startSpin2 );
    d2=0.5;
}

let timeoutHandler2;
let reverse2 = false;
let d2 =0.5;
function rotateYoYoMa2(){
    let element2 = '02';
    if(reverse2 === false){
        currentImage2++;
        d2+=2;
        if(currentImage2 >249){
            currentImage2 = 1;
        }

        $(`#die${element2}`).attr('src', `images/rolling-die2/dice_animation_${currentImage2}.png`);
    }else if(reverse2 === true){
        currentImage2--;
        d2+=2;
        if(currentImage2 < 1){
            currentImage2 = 250;
            }
            $(`#die${element2}]`).attr('src', `images/rolling-die2/dice_animation_${currentImage2}.png`);
        }
    
    timeoutHandler2 = setTimeout(function(){
        animationDiceHandler2 = requestAnimationFrame( rotateYoYoMa2 );
    },0.01*d2);
}

let reset2 = () => {


    die2.style.position =`absolute`;
    die2.style.top = `0%`;
    die2.style.left = `0%`;
    die2.style.width.left = `5%`;
    die2.style.height = `auto`;
    die2.style.transform = 'none';
    moveRight2= true;
    $(die2).attr('src', `images/rolling-die2/dice_animation_1.png`);
    startBtn.addEventListener('click', startRoll2);
    startBtn.addEventListener('click', startSpin2 );
    die_02.pos = [ 0, 0 ];
    die_02.vel = [ 2, 6 ];
  };


let returnImage2; 

let timeoutHandler3;
function roll2(){
    let dMs2 = 250;
    let dst2 = dMs2 * 0.001;
    let vMagT2 = Math.hypot(die_02.vel[0], die_02.vel[1]);
    let dx2 = die_02.pos[0] - die_02.startPos[0];
    let dy2 = die_02.pos[1] - die_02.startPos[1];
    let rangeRemainder2 = die_02.range - Math.hypot(dx2, dy2);
    let veloC2 = 1 - Math.max(0, Math.min(1, dst2 * vMagT2 / rangeRemainder2));
    if(moveRight2 === true){ 
        die_02.vel[0] *= veloC2;
        die_02.vel[1] *= veloC2;
        die_02.pos[0] += (die_02.vel[0] * dst2);
        die_02.pos[1] += (die_02.vel[1] * dst2);
        if(die_02.pos[0] > 22){
            moveRight2 = false;
            die2.style.transform = 'scaleX(-1)';
        }
        die2.style.left = `${die_02.pos[0]}%`;
        die2.style.top = `${die_02.pos[1]}%`;
    }else if(moveRight2 === false){ 
        die_02.vel[0] *= veloC2;
        die_02.vel[1] *= veloC2;
        die_02.pos[0] += (die_02.vel[0] * dst2);
        die_02.pos[1] = die_02.pos[1]- die_02.vel[1] * dst2;
        if(die_02.pos[0] < 10){
            moveRight2 = true;
            die2.style.transform = 'scaleX(1)';
        }
        die2.style.left = `${die_02.pos[0]}%`;
        die2.style.top = `${die_02.pos[1]}%`;
    }
    timeoutHandler3 = setTimeout(function(){
    rollHandler2 = requestAnimationFrame( roll2 );
    if (moveRight2 === false && die_02.pos[1] < 53){
    //if (moveRight === false && die_01.pos[0] < 57){//add in vMagT
        let element2= die_02.element;
        cancelAnimationFrame(rollHandler2);
        cancelAnimationFrame( animationDiceHandler2 );
        clearTimeout( timeoutHandler2);
        clearTimeout( timeoutHandler3);
        let theDie2 = new Dice2();
        theDie2.shake();
        returnImage2 = theDie2.result();
        if(opponentTurn === true){
            playerTwo.addDieToHand(returnImage2);
        }else{
            playerOne.addDieToHand(returnImage2);
        }
        $(`#die${element2}`).attr('src', `images/final-die/${returnImage2}.png`);
    }
    });
}

//////

reverseBtn.addEventListener('click', function(){
    if(opponentTurn ===false && die2.style.top != `72%`){
        playerOne.returnDieToCup();
        die_02.pos = [ 0, 0 ];
        die_02.vel = [ 2, 6 ];
        die_02.startPos = [ 0, 0 ];
        die_02.range = 90;
        die2.style.left = `${die_02.pos[0]}%`;
        die2.style.top = `${die_02.pos[1]}%`;
        reset2();
    }else if(opponentTurn === true && die2.style.top != `18%`){
        playerTwo.returnDieToCup();
        die_02.pos = [ 0, 0 ];
        die_02.vel = [ 2, 6 ];
        die_02.startPos = [ 0, 0 ];
        die_02.range = 90;
        die2.style.left = `${die_02.pos[0]}%`;
        die2.style.top = `${die_02.pos[1]}%`;
        reset2();
    }
});

die2.addEventListener('click', function(){
    if(opponentTurn ===false && die2.style.top != `72%`){
        die2.style.left = `11.5%`;
        die2.style.top = `72%`;
        playerOne.addDieToKeep(returnImage2);
        playerOne.filterTheFilth(returnImage2);
        if(masterArray.length < 6){
            masterArray.push(die2);  
        }
        if (playerOne.masterArray.length === 5){
            change();
        }
    }else if(opponentTurn ===true && die2.style.top != `18%`){
        die2.style.left = `65%`;
        die2.style.top = `18%`;
        playerTwo.addDieToKeep(returnImage2);
        playerTwo.filterTheFilth(returnImage2);
        if(masterEnemyArray.length < 6){
            masterEnemyArray.push(die2);  
        }
        if (playerTwo.masterArray.length === 5){
            change();
        }
    }
    die_02.pos = [ 0, 0 ];
    die_02.vel = [ 2, 6 ];
    die_02.startPos = [ 0, 0 ];
    die_02.range = 90;
    startBtn.removeEventListener('click', startRoll2 );
    startBtn.removeEventListener('click', startSpin2 );
    
});
 // });
 /////Die 3//////
 let rollHandler3;

 let animationDiceHandler3;
 
 startBtn.addEventListener('click', startSpin3);
 startBtn.addEventListener('click', startRoll3);
 
 function startRoll3(){
     rollHandler3 = requestAnimationFrame( roll3 );
     startBtn.removeEventListener('click', startRoll3 );
 };
 
 function startSpin3(){
     animationDiceHandler3 = requestAnimationFrame( rotateYoYoMa3 );
     startBtn.removeEventListener('click', startSpin3 );
     d3=0.5;
 }
 
 let timeoutHandler4;
 let reverse3 = false;
 let d3 =0.5;
 function rotateYoYoMa3(){
     let element3 = '03';
     if(reverse3 === false){
         currentImage3++;
         d3+=2;
         if(currentImage3 >249){
             currentImage3 = 1;
         }
 
         $(`#die${element3}`).attr('src', `images/rolling-die2/dice_animation_${currentImage3}.png`);
     }else if(reverse3 === true){
         currentImage3--;
         d3+=2;
         if(currentImage3 < 1){
             currentImage3 = 250;
             }
             $(`#die${element3}]`).attr('src', `images/rolling-die2/dice_animation_${currentImage3}.png`);
         }
     
     timeoutHandler4 = setTimeout(function(){
         animationDiceHandler3 = requestAnimationFrame( rotateYoYoMa3 );
     },0.01*d3);
 }
 
 let reset3 = () => {
 
 
     die3.style.position =`absolute`;
     die3.style.top = `0%`;
     die3.style.left = `0%`;
     die3.style.width.left = `5%`;
     die3.style.height = `auto`;
     die3.style.transform = 'none';
     moveRight3= true;
     $(die3).attr('src', `images/rolling-die2/dice_animation_1.png`);
     startBtn.addEventListener('click', startRoll3);
     startBtn.addEventListener('click', startSpin3 );
     die_03.pos = [ 0, 0 ];
     die_03.vel = [ 6, 4 ];
   };
 
 let returnImage3;
 
 let timeoutHandler5;
 function roll3(){
     let dMs3 = 90;
     let dst3 = dMs3 * 0.001;
     let vMagT3 = Math.hypot(die_03.vel[0], die_03.vel[1]);
     let dx3 = die_03.pos[0] - die_03.startPos[0];
     let dy3 = die_03.pos[1] - die_03.startPos[1];
     let rangeRemainder3 = die_03.range - Math.hypot(dx3, dy3);
     let veloC3 = 1 - Math.max(0, Math.min(1, dst3 * vMagT3 / rangeRemainder3));
     if(moveRight3 === true){ 
         die_03.vel[0] *= veloC3;
         die_03.vel[1] *= veloC3;
         die_03.pos[0] += (die_03.vel[0] * dst3);
         die_03.pos[1] += (die_03.vel[1] * dst3);
         if(die_03.pos[0] > 80){
             moveRight3 = false;
             die3.style.transform = 'scaleX(-1)';
         }
         die3.style.left = `${die_03.pos[0]}%`;
         die3.style.top = `${die_03.pos[1]}%`;
     }else if(moveRight3 === false){  
         die_03.vel[0] *= veloC3;
         die_03.vel[1] *= veloC3;
         die_03.pos[0] = die_03.pos[0]- die_03.vel[0] * dst3;
         die_03.pos[1]  += (die_03.vel[1] * dst3)*1/Math.PI;
         if(die_03.pos[0] < 10){
             moveRight3 = true;
             die3.style.transform = 'scaleX(1)';
         }
         die3.style.left = `${die_03.pos[0]}%`;
         die3.style.top = `${die_03.pos[1]}%`;
     }
     timeoutHandler5 = setTimeout(function(){
     rollHandler3 = requestAnimationFrame( roll3 );
     if (moveRight3 === false && die_03.pos[0] < 73){
     //if (moveRight === false && die_01.pos[0] < 57){//add in vMagT
         let element3= die_03.element;
         cancelAnimationFrame(rollHandler3);
         cancelAnimationFrame( animationDiceHandler3 );
         clearTimeout( timeoutHandler4);
         clearTimeout( timeoutHandler5);
         let theDie3 = new Dice3();
         theDie3.shake();
         returnImage3 = theDie3.result();
         if(opponentTurn === true){
            playerTwo.addDieToHand(returnImage3);
        }else{
        playerOne.addDieToHand(returnImage3);
        }
         $(`#die${element3}`).attr('src', `images/final-die/${returnImage3}.png`);
     }
     });
 }
 
 //////
 reverseBtn.addEventListener('click', function(){
    if(opponentTurn ===false && die3.style.top != `78%`){
        playerOne.returnDieToCup();
        die_03.pos = [ 0, 0 ];
        die_03.vel = [ 6, 4 ];
        die_03.startPos = [ 0, 0 ];
        die_03.range = 240;
        die3.style.left = `${die_03.pos[0]}%`;
        die3.style.top = `${die_03.pos[1]}%`;
        reset3();
    }else if(opponentTurn === true && die3.style.top != `20%`){
        playerTwo.returnDieToCup();
        die_03.pos = [ 0, 0 ];
        die_03.vel = [ 6, 4 ];
        die_03.startPos = [ 0, 0 ];
        die_03.range = 240;
        die3.style.left = `${die_03.pos[0]}%`;
        die3.style.top = `${die_03.pos[1]}%`;
        reset3();
    }
});

die3.addEventListener('click', function(){
    if(opponentTurn ===false && die3.style.top != `78%`){
        die3.style.left = `20%`;
        die3.style.top = `78%`;
        playerOne.addDieToKeep(returnImage3);
        playerOne.filterTheFilth(returnImage3);
        if(masterArray.length < 6){
            masterArray.push(die3);  
        }
        if (playerOne.masterArray.length === 5){
            change();
        }
    }else if(opponentTurn === true && die3.style.top != `20%`){
        die3.style.left = `75%`;
        die3.style.top = `20%`;
        playerTwo.addDieToKeep(returnImage3);
        playerTwo.filterTheFilth(returnImage3);
        if(masterEnemyArray.length < 6){
            masterEnemyArray.push(die3);  
        }
        if (playerTwo.masterArray.length === 5){
            change();
        }
    }
    die_03.pos = [ 0, 0 ];
    die_03.vel = [ 6, 4 ];
    die_03.startPos = [ 0, 0 ];
    die_03.range = 240;
    startBtn.removeEventListener('click', startRoll3 );
    startBtn.removeEventListener('click', startSpin3 );
    
});
  
 /////End Die 3/////

 /////Start Die 4//////
 let rollHandler4;

 let animationDiceHandler4;
 
 startBtn.addEventListener('click', startSpin4);
 startBtn.addEventListener('click', startRoll4);
 
 function startRoll4(){
     rollHandler4 = requestAnimationFrame( roll4 );
     startBtn.removeEventListener('click', startRoll4 );
 };
 
 function startSpin4(){
     animationDiceHandler4 = requestAnimationFrame( rotateYoYoMa4 );
     startBtn.removeEventListener('click', startSpin4 );
     d4=0.5;
 }
 
 let timeoutHandler6;
 let reverse4 = false;
 let d4 =0.5;
 function rotateYoYoMa4(){
     let element4 = '04';
     if(reverse4 === false){
         currentImage4++;
         d4+=2;
         if(currentImage4 >249){
             currentImage4 = 1;
         }
 
         $(`#die${element4}`).attr('src', `images/rolling-die2/dice_animation_${currentImage4}.png`);
     }else if(reverse4 === true){
         currentImage4--;
         d4+=2;
         if(currentImage4 < 1){
             currentImage4 = 250;
             }
             $(`#die${element4}]`).attr('src', `images/rolling-die2/dice_animation_${currentImage4}.png`);
         }
     
     timeoutHandler6 = setTimeout(function(){
         animationDiceHandler4 = requestAnimationFrame( rotateYoYoMa4 );
     },0.01*d4);
 }
 
 let reset4 = () => {
 
 
     die4.style.position =`absolute`;
     die4.style.top = `0%`;
     die4.style.left = `0%`;
     die4.style.width.left = `5%`;
     die4.style.height = `auto`;
     die4.style.transform = 'none';
     moveRight4= true;
     $(die4).attr('src', `images/rolling-die2/dice_animation_1.png`);
     startBtn.addEventListener('click', startRoll4);
     startBtn.addEventListener('click', startSpin4 );
     die_04.pos = [ 0, 0 ];
     die_04.vel = [ 3, 4 ];
   };
 
 let returnImage4;
 
 let timeoutHandler7;
 function roll4(){
     let dMs4 = 130;
     let dst4 = dMs4 * 0.001;
     let vMagT4 = Math.hypot(die_04.vel[0], die_04.vel[1]);
     let dx4 = die_04.pos[0] - die_04.startPos[0];
     let dy4 = die_04.pos[1] - die_04.startPos[1];
     let rangeRemainder4 = die_04.range - Math.hypot(dx4, dy4);
     let veloC4 = 1 - Math.max(0, Math.min(1, dst4 * vMagT4 / rangeRemainder4));
     if(moveRight4 === true){ 
         die_04.vel[0] *= veloC4;
         die_04.vel[1] *= veloC4;
         die_04.pos[0] += (die_04.vel[0] * dst4);
         die_04.pos[1] += (die_04.vel[1] * dst4);
         if(die_04.pos[0] > 55){
             moveRight4 = false;
             die4.style.transform = 'scaleX(-1)';
         }
         die4.style.left = `${die_04.pos[0]}%`;
         die4.style.top = `${die_04.pos[1]}%`;
     }else if(moveRight4 === false){  
         die_04.vel[0] *= veloC4;
         die_04.vel[1] *= veloC4;
         die_04.pos[0] = die_04.pos[0]- die_04.vel[0] * dst4;
         die_04.pos[1]  += (die_04.vel[1] * dst4)*0.11/Math.PI;
         if(die_04.pos[0] < 10){
             moveRight4 = true;
             die4.style.transform = 'scaleX(1)';
         }
         die4.style.left = `${die_04.pos[0]}%`;
         die4.style.top = `${die_04.pos[1]}%`;
     }
     timeoutHandler7 = setTimeout(function(){
     rollHandler4 = requestAnimationFrame( roll4 );
     if (moveRight4 === false && die_04.pos[0] < 47){
     //if (moveRight === false && die_01.pos[0] < 57){//add in vMagT
         let element4= die_04.element;
         cancelAnimationFrame(rollHandler4);
         cancelAnimationFrame( animationDiceHandler4 );
         clearTimeout( timeoutHandler6);
         clearTimeout( timeoutHandler7);
         let theDie4 = new Dice4();
         theDie4.shake();
         returnImage4 = theDie4.result();
         if(opponentTurn === true){
            playerTwo.addDieToHand(returnImage4);
        }else{
        playerOne.addDieToHand(returnImage4);
        }
         $(`#die${element4}`).attr('src', `images/final-die/${returnImage4}.png`);
     }
     });
 }
 
 //////
 reverseBtn.addEventListener('click', function(){
    if(opponentTurn ===false && die4.style.top != `82%`){
        playerOne.returnDieToCup();
        die_04.pos = [ 0, 0 ];
        die_04.vel = [ 3, 4 ];
        die_04.startPos = [ 0, 0 ];
        die_04.range = 240;
        die4.style.left = `${die_04.pos[0]}%`;
        die4.style.top = `${die_04.pos[1]}%`;
        reset4();
    }else if(opponentTurn === true && die4.style.top != `27%`){
        playerTwo.returnDieToCup();
        die_04.pos = [ 0, 0 ];
        die_04.vel = [ 3, 4 ];
        die_04.startPos = [ 0, 0 ];
        die_04.range = 240;
        die4.style.left = `${die_04.pos[0]}%`;
        die4.style.top = `${die_04.pos[1]}%`;
        reset4();
    }
});

die4.addEventListener('click', function(){
    if(opponentTurn ===false && die4.style.top != `82%`){
        die4.style.left = `30%`;
        die4.style.top = `82%`;
        playerOne.addDieToKeep(returnImage4);
        playerOne.filterTheFilth(returnImage4);
        if(masterArray.length < 6){
            masterArray.push(die4);  
        }
        if (playerOne.masterArray.length === 5){
            change();
        }
    }else if(opponentTurn === true && die4.style.top != `27%`){
        die4.style.left = `85%`;
        die4.style.top = `27%`;
        playerTwo.addDieToKeep(returnImage4);
        playerTwo.filterTheFilth(returnImage4);
        if(masterEnemyArray.length < 6){
            masterEnemyArray.push(die4);  
        }
        if (playerTwo.masterArray.length === 5){
            change();
        }
    }
    die_04.pos = [ 0, 0 ];
    die_04.vel = [ 3, 4 ];
    die_04.startPos = [ 0, 0 ];
    die_04.range = 240;
    startBtn.removeEventListener('click', startRoll4 );
    startBtn.removeEventListener('click', startSpin4 );
    
});
  // });
 /////End Die 4/////

 /////Start Die 5/////

  let rollHandler5;

  let animationDiceHandler5;
  
  startBtn.addEventListener('click', startSpin5);
  startBtn.addEventListener('click', startRoll5);
  
  function startRoll5(){
      rollHandler5 = requestAnimationFrame( roll5 );
      startBtn.removeEventListener('click', startRoll5 );
  };
  
  function startSpin5(){
      animationDiceHandler5 = requestAnimationFrame( rotateYoYoMa5 );
      startBtn.removeEventListener('click', startSpin5 );
      d5=0.5;
  }
  
  let timeoutHandler8;
  let reverse5 = false;
  let d5 =0.5;
  function rotateYoYoMa5(){
      let element5 = '05';
      if(reverse5 === false){
          currentImage5++;
          d5+=2;
          if(currentImage5 >249){
              currentImage5 = 1;
          }
  
          $(`#die${element5}`).attr('src', `images/rolling-die2/dice_animation_${currentImage5}.png`);
      }else if(reverse5 === true){
          currentImage5--;
          d5+=2;
          if(currentImage5 < 1){
              currentImage5 = 250;
              }
              $(`#die${element5}]`).attr('src', `images/rolling-die2/dice_animation_${currentImage5}.png`);
          }
      
      timeoutHandler8 = setTimeout(function(){
          animationDiceHandler5 = requestAnimationFrame( rotateYoYoMa5 );
      },0.01*d5);
  }
  
  let reset5 = () => {
  
  
      die5.style.position =`absolute`;
      die5.style.top = `0%`;
      die5.style.left = `0%`;
      die5.style.width.left = `5%`;
      die5.style.height = `auto`;
      die5.style.transform = 'none';
      moveRight5= true;
      $(die5).attr('src', `images/rolling-die2/dice_animation_1.png`);
      startBtn.addEventListener('click', startRoll5);
      startBtn.addEventListener('click', startSpin5 );
      die_05.pos = [ 0, 0 ];
      die_05.vel = [ 4, 4 ];
    };
  
  let returnImage5;
  
  let timeoutHandler9;
  function roll5(){
      let dMs5 = 230;
      let dst5 = dMs5 * 0.001;
      let vMagT5 = Math.hypot(die_05.vel[0], die_05.vel[1]);
      let dx5 = die_05.pos[0] - die_05.startPos[0];
      let dy5 = die_05.pos[1] - die_05.startPos[1];
      let rangeRemainder5 = die_05.range - Math.hypot(dx5, dy5);
      let veloC5 = 1 - Math.max(0, Math.min(1, dst5 * vMagT5 / rangeRemainder5));
      if(moveRight5 === true){ 
          die_05.vel[0] *= veloC5;
          die_05.vel[1] *= veloC5;
          die_05.pos[0] += (die_05.vel[0] * dst5);
          die_05.pos[1] += (die_05.vel[1] * dst5);
          if(die_05.pos[0] > 55){
              moveRight5 = false;
              die5.style.transform = 'scaleX(-1)';
          }
          die5.style.left = `${die_05.pos[0]}%`;
          die5.style.top = `${die_05.pos[1]}%`;
      }else if(moveRight5 === false){  
          die_05.vel[0] *= veloC5;
          die_05.vel[1] *= veloC5;
          die_05.pos[0] = die_05.pos[0]- die_05.vel[0] * dst5;
          die_05.pos[1]  += (die_05.vel[1] * dst5)*0.11/Math.PI;
          if(die_05.pos[0] < 10){
              moveRight5 = true;
              die5.style.transform = 'scaleX(1)';
          }
          die5.style.left = `${die_05.pos[0]}%`;
          die5.style.top = `${die_05.pos[1]}%`;
      }
      timeoutHandler9 = setTimeout(function(){
      rollHandler5 = requestAnimationFrame( roll5 );
      if (moveRight5 === false && die_05.pos[0] < 47){
      //if (moveRight === false && die_01.pos[0] < 57){//add in vMagT
          let element5= die_05.element;
          cancelAnimationFrame(rollHandler5);
          cancelAnimationFrame( animationDiceHandler5 );
          clearTimeout( timeoutHandler8);
          clearTimeout( timeoutHandler9);
          let theDie5 = new Dice5();
          theDie5.shake();
          returnImage5 = theDie5.result();
          if(opponentTurn === true){
            playerTwo.addDieToHand(returnImage5);
        }else{
        playerOne.addDieToHand(returnImage5);
        }
          $(`#die${element5}`).attr('src', `images/final-die/${returnImage5}.png`);
      }
      });
  }
  
  //////

  reverseBtn.addEventListener('click', function(){
    if(opponentTurn ===false && die5.style.top != `83%`){
        playerOne.returnDieToCup();
        die_05.pos = [ 0, 0 ];
        die_05.vel = [ 4, 4 ];
        die_05.startPos = [ 0, 0 ];
        die_05.range = 100;
        die5.style.left = `${die_05.pos[0]}%`;
        die5.style.top = `${die_05.pos[1]}%`;
        reset5();
    }else if(opponentTurn === true && die5.style.top != `38%`){
        playerTwo.returnDieToCup();
        die_05.pos = [ 0, 0 ];
        die_05.vel = [ 4, 4 ];
        die_05.startPos = [ 0, 0 ];
        die_05.range = 100;
        die5.style.left = `${die_05.pos[0]}%`;
        die5.style.top = `${die_05.pos[1]}%`;
        reset5();
    }
});

die5.addEventListener('click', function(){
    if(opponentTurn ===false && die5.style.top != `83%`){
        die5.style.left = `40%`;
        die5.style.top = `83%`;
        playerOne.addDieToKeep(returnImage5);
        playerOne.filterTheFilth(returnImage5);
        if(masterArray.length < 6){
            masterArray.push(die5);  
        }
        if (playerOne.masterArray.length === 5){
            change();
        }
    }else if(opponentTurn === true && die5.style.top != `38%`){
        die5.style.left = `90%`;
        die5.style.top = `38%`;
        playerTwo.addDieToKeep(returnImage5);
        playerTwo.filterTheFilth(returnImage5);
        if(masterEnemyArray.length < 6){
            masterEnemyArray.push(die5);  
        }
        if (playerTwo.masterArray.length === 5){
            change();
        }
    }
    die_05.pos = [ 0, 0 ];
    die_05.vel = [ 4, 4 ];
    die_05.startPos = [ 0, 0 ];
    die_05.range = 100;
    startBtn.removeEventListener('click', startRoll5 );
    startBtn.removeEventListener('click', startSpin5 );
    
});
   // });
  /////End Die 5/////


///////

 class Dice{
    constructor(){
        this.dice = [1, 2, 3, 4, 5, 6,];
    }
}

Dice.prototype.result = function(){
    const curDice = this.dice.shift();
    //if we have run out of cards...
    if(curDice === undefined){
        return 'No more ';
    }else{
        //return the next card in the array
        return curDice;
    }         
}
Dice.prototype.shake = function(){
 
    let i, j, k;
    for (i = this.dice.length - 1; i > 0; i--) {
        j = Math.floor(Math.random() * (i + 1));
        k = this.dice[i];
        this.dice[i] = this.dice[j];
        this.dice[j] = k;
    }
    return this.dice;       
}
Dice.prototype.jingoJango = function(){
    let dice1;
    do{
    dice1 = new Dice();
    }while(dice1 == new Dice());
    dice1.shake();
    currentImage = dice1.result();
    return currentImage;
};
class Dice2{
    constructor(){
        this.dice = [1, 2, 3, 4, 5, 6,];
    }
}

Dice2.prototype.result = function(){
    const curDice = this.dice.shift();
    //if we have run out of cards...
    if(curDice === undefined){
        return 'No more ';
    }else{
        //return the next card in the array
        return curDice;
    }         
}
Dice2.prototype.shake = function(){
 
    let i, j, k;
    for (i = this.dice.length - 1; i > 0; i--) {
        j = Math.floor(Math.random() * (i + 1));
        k = this.dice[i];
        this.dice[i] = this.dice[j];
        this.dice[j] = k;
    }
    return this.dice;       
}
class Dice3{
    constructor(){
        this.dice = [1, 2, 3, 4, 5, 6,];
    }
}

Dice3.prototype.result = function(){
    const curDice = this.dice.shift();
    //if we have run out of cards...
    if(curDice === undefined){
        return 'No more ';
    }else{
        //return the next card in the array
        return curDice;
    }         
}
Dice3.prototype.shake = function(){
 
    let i, j, k;
    for (i = this.dice.length - 1; i > 0; i--) {
        j = Math.floor(Math.random() * (i + 1));
        k = this.dice[i];
        this.dice[i] = this.dice[j];
        this.dice[j] = k;
    }
    return this.dice;       
}
class Dice4{
    constructor(){
        this.dice = [1, 2, 3, 4, 5, 6,];
    }
}

Dice4.prototype.result = function(){
    const curDice = this.dice.shift();
    //if we have run out of cards...
    if(curDice === undefined){
        return 'No more ';
    }else{
        //return the next card in the array
        return curDice;
    }         
}
Dice4.prototype.shake = function(){
 
    let i, j, k;
    for (i = this.dice.length - 1; i > 0; i--) {
        j = Math.floor(Math.random() * (i + 1));
        k = this.dice[i];
        this.dice[i] = this.dice[j];
        this.dice[j] = k;
    }
    return this.dice;       
}
class Dice5{
    constructor(){
        this.dice = [1, 2, 3, 4, 5, 6,];
    }
}

Dice5.prototype.result = function(){
    const curDice = this.dice.shift();
    //if we have run out of cards...
    if(curDice === undefined){
        return 'No more ';
    }else{
        //return the next card in the array
        return curDice;
    }         
}
Dice5.prototype.shake = function(){
 
    let i, j, k;
    for (i = this.dice.length - 1; i > 0; i--) {
        j = Math.floor(Math.random() * (i + 1));
        k = this.dice[i];
        this.dice[i] = this.dice[j];
        this.dice[j] = k;
    }
    return this.dice;       
}
class Player{
    constructor( playerName ){
        this.playerName = playerName;
        this.buildRolled =[];
        this.masterArray =[];
    }
    addDieToHand( aDie ){
            this.buildRolled.push(aDie);
            console.log(`${aDie}`);
    }
    addDieToKeep( aDie ){
        if(this.masterArray.length < 5){
            this.masterArray.push(aDie);
            output.innerHTML = playerOne.describeSelf();
            output2.innerHTML = playerTwo.describeSelf();
        }else{
        console.log(` ${aDie}`);
        }
}
    filterTheFilth( aDie ){
        this.buildRolled.filter( aDie );
            return item !== aDie;
        }

    };
Player.prototype.purgeKeep =function (){
    for(i = this.masterArray.length; i > 0; i--){
            this.masterArray.pop();
        output.innerHTML = playerOne.describeSelf();
        output2.innerHTML = playerTwo.describeSelf();
    };
};
Player.prototype.filterTheFilth = function(){
    this.buildRolled = this.buildRolled.filter(function(item) {
        return item !== item;
})
}
Player.prototype.returnDieToCup = function(){
    //masterArray.forEach(( master ) => {
     //   if( master )
   // });
   this.buildRolled.forEach(() => {
        this.buildRolled.pop();
    });
    //const rerollDice = this.buildRolled.pop();
    output.innerHTML = playerOne.describeSelf();  
    output2.innerHTML = playerTwo.describeSelf();    
}
Player.prototype.grabLength = function(){
    let length = this.buildRolled.length;
    return length;  
}; 


Player.prototype.describeSelf = function(){
    description = `<h4>${this.playerName}</h4>`;
    description += '<ul>';
    this.masterArray.forEach((rolled) => {
         description +=`<li>${rolled}</li>`;
    })
    description += `</ul>`;
    return description;  
}; 
Player.prototype.sorting = function(){
    points = this.masterArray;
    points.sort(function(a, b){return a - b});
    return points;
}
Player.prototype.sorting4 = function(){
    points = this.masterArray;
    points.sort(function(a, b){return a - b});
    return points;
}

let playerOne = new Player("You");

let playerTwo = new Player("Opponent");


if( playerTwo instanceof Player){
    output2.innerHTML += playerTwo.describeSelf();
}

if( playerOne instanceof Player){
    output.innerHTML += playerOne.describeSelf();
}




//if( playerOneHand instanceof FullHand){
   // output2.innerHTML += playerOne.describeSelf();

//}
//if( playerOneHand instanceof FullHand){
   // output2.innerHTML += playerOne.describeSelf();
//}
$('#aces, #twos, #threes, #fours, #fives, #sixes, #full-house, #lg-straight, #sm-straight, #four-of-a-kind, #three-of-a-kind, #yahtzee, #chance').on("input", function(){
    $(this).prop("disabled", true);
    $('#aces, #twos, #threes, #fours, #fives, #sixes, #full-house, #lg-straight, #sm-straight, #four-of-a-kind, #three-of-a-kind, #yahtzee, #chance').prop("disabled", true);
    scorecard.classList.toggle("visible");
    scorecard.classList.toggle("invisible");
    letLifeGoOn = true;
    playerTwo.purgeKeep();
    //playerOne.purgeKeep();///forgot to comment purge keep function after testing
    });
$('#aces2, #twos2, #threes2, #fours2, #fives2, #sixes2, #full-house2, #lg-straight2, #sm-straight2, #four-of-a-kind2, #three-of-a-kind2, #yahtzee2, #chance2').on("input", function(){
    $(this).prop("disabled", true);
    $('#aces2, #twos2, #threes2, #fours2, #fives2, #sixes2, #full-house2, #lg-straight2, #sm-straight2, #four-of-a-kind2, #three-of-a-kind2, #yahtzee2, #chance2').prop("disabled", true);
    scorecard2.classList.toggle("visible");
    scorecard2.classList.toggle("invisible");
    letLifeGoOn = true;
    playerOne.purgeKeep();
    //playerTwo.purgeKeep();///forgot to comment purge keep function after testing
    //
    });

////////
///////
///////
let playerTwoScore = 0;
$('#display-total2').html(`${playerTwoScore}`);

$('#lg-straight2').on("input", function(){
        //if(playerTwo.sorting() == [2,3,4,5,6] || playerTwo.sorting() == [1,2,3,4,5]){
          //  console.log("Large Straight! 40 points!");
            playerTwoScore+=40;
    //}
});
$('#sm-straight2').on("input", function(){
    //let middle = playerTwo.sorting().shift();
    //let middle2 = playerTwo.sorting().pop();
    //if(middle == [1,2,3,4] || middle == [2,3,4,5] || middle2 == [3,4,5,6]){
        //console.log("Large Straight! 30 points!");
        playerTwoScore+=30;
        $('#display-total2').html(`${playerTwoScore}`);
   // }
});
$('#yahtzee2').on("input", function(){
        playerTwoScore+=50;
        $('#display-total2').html(`${playerTwoScore}`);
    }
);
$('#chance2').on("input", function(){
    playerTwo.sorting().forEach(element => {
        playerTwoScore+=element;
    });
    $('#display-total2').html(`${playerTwoScore}`);
}
);
$('#full-house2').on("input", function(){
        playerTwoScore+=25;
        $('#display-total').html(`${playerOneScore}`);
    });
$('#aces2').on("input", function(){
    playerTwo.sorting().forEach(element => {
        if(element == 1){
        playerTwoScore++;
        }
    });
    $('#display-total2').html(`${playerTwoScore}`);
}
);
$('#twos2').on("input", function(){
   // playerTwo.sorting().forEach(element => {
        //if(element == 2){
            playerTwoScore+= 2;
        //}
   // });
    $('#display-total2').html(`${playerTwoScore}`);
}
);
$('#threes2').on("input", function(){
    playerTwo.sorting().forEach(element => {
        if(element == 3){
        playerTwoScore+= 3;
        }
    });
    $(`#display-total2`).html(`${playerTwoScore}`);
}
);
$('#fours2').on("input", function(){
    playerTwo.sorting().forEach(element => {
        if(element == 4){
            playerTwoScore+= 4;
        }
    });
    $(`#display-total2`).html(`${playerTwoScore}`);
}
);
$('#fives2').on("input", function(){
    playerTwo.sorting().forEach(element => {
        if(element === 5){
        playerTwoScore+= 5;
        }
    });
    $(`#display-total2`).html(`${playerTwoScore}`);
}
);
$('#sixes2').on("input", function(){
    playerTwo.sorting().forEach(element => {
        if(element == 6){
        playerTwoScore+= 6;
        }
    });
    $(`#display-total2`).html(`${playerTwoScore}`);
}
);
$('#three-of-a-kind2').on("input", function(){
    playerTwo.sorting().forEach(element => {
        playerTwoScore+= element;
        });
    });
$('#four-of-a-kind2').on("input", function(){
    playerTwo.sorting().forEach(element => {
        playerTwoScore+= element;
        });
    });
/////

/////

let playerOneScore = 0;
$('#display-total').html(`${playerOneScore}`);
$('#lg-straight').on("input", function(){
        //if(playerOne.sorting() == [2,3,4,5,6] || playerOne.sorting() == [1,2,3,4,5]){
           // console.log("Large Straight! 40 points!");
            playerOneScore+=40;
            $('#display-total').html(`${playerOneScore}`);
   // }
});
$('#sm-straight').on("input", function(){
   // let middle = playerOne.sorting().shift();
   // let middle2 = playerOne.sorting().pop();
   // if(middle == [1,2,3,4] || middle == [2,3,4,5] || middle2 == [3,4,5,6]){
       // console.log("Large Straight! 30 points!");
        playerOneScore+=30;
    //}
    $('#display-total').html(`${playerOneScore}`);
});
$('#yahtzee').on("input", function(){
        playerOneScore+=50;
    //}
    $('#display-total').html(`${playerOneScore}`);
});
$('#chance').on("input", function(){
    playerOne.sorting().forEach(element => {
        playerOneScore+=element;
    });
    $('#display-total').html(`${playerOneScore}`);
}
);
$('#full-house').on("input", function(){
        playerOneScore+=25;
        $('#display-total').html(`${playerOneScore}`);
    });
$('#aces').on("input", function(){
    playerOne.sorting().forEach(element => {
        if(element == 1){
        playerOneScore+= 1;
        }
    });
    $('#display-total').html(`${playerOneScore}`);
}
);
$('#twos').on("input", function(){
    playerOne.sorting().forEach(element => {
        if(element == 2){
        playerOneScore+= 2;
        }
    });
    $('#display-total').html(`${playerOneScore}`);
}
);
$('#threes').on("input", function(){
    playerOne.sorting().forEach(element => {
        if(element == 3){
        playerOneScore+= 3;
        }
    });
    $(`#display-total2`).html(`${playerTwoScore}`);
}
);
$('#fours').on("input", function(){
    playerOne.sorting().forEach(element => {
        if(element == 4){
        playerOneScore+= 4;
        }
    });
    $('#display-total').html(`${playerOneScore}`);
}
);
$('#fives').on("input", function(){
    playerOne.sorting().forEach(element => {
        if(element == 5){
        playerOneScore+= 5;
        }
    });
    $('#display-total').html(`${playerOneScore}`);
}
);
$('#sixes').on("input", function(){
    playerOne.sorting().forEach(element => {
        if(element == 6){
        playerOneScore+= 6;
        }
    });
    $('#display-total').html(`${playerOneScore}`);
}
);
$('#three-of-a-kind').on("input", function(){
    playerOne.sorting().forEach(element => {
        playerOneScore+= element;
        });
        $('#display-total').html(`${playerOneScore}`);
    });
$('#three-of-a-kind').on("input", function(){
    playerOne.sorting().forEach(element => {
        playerOneScore+= element;
        });
        $('#display-total').html(`${playerOneScore}`);
    });