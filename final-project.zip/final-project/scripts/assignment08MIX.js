
/*
Author: Dustin Lloyd A01360009
*/

const $imageWindow       = $('#view-product-window');
const $BtnMenu          = $('#btn-menu');
const $siteNav          = $('nav');
const popUp             = document.querySelector('article');
const startBtn          = document.querySelector('#start-btn');
const stopBtn           = document.querySelector('#stop-btn');
const reverseBtn        = document.querySelector('#reverse-btn');
const popUpBack         = document.querySelector('#popup-01');
const delay             = 3000;
const heading       = document.querySelector('h2');
heading.classList.add('some-gd-decor');
const popUpBtn          = document.querySelector('#popup-btn');
const popUpBtnOut       = document.querySelector('#popup-btn-output');
let positionStart       = 0;
const positionEnd       = 15;
heading.style.position = 'relative';
let currentImage        = 1;
//let position = 0;
let position2 = 30;
let position3 = 60;
let moveRight = true;
let moveRight2 = true;
let moveRight3 = true;
const intervalInMilliseconds = 20;
const die               =document.querySelector('#die01');
const die2               =document.querySelector('#die02');
const die3               =document.querySelector('#die03');
const die4               =document.querySelector('#die04');
const die5               =document.querySelector('#die05');
const die6               =document.querySelector('#die06');


/////////// adding my dice object array here
let die_01 = {
    pos: [ 0, 0 ],
    vel: [ 4, 5 ],
    startPos: [ 0, 0 ],
    range: 100
  };
  let die_02 = {
    pos: [ 0, 0 ],
    vel: [ 4, 2 ],
    startPos: [ 0, 0 ],
    range: 80,
    element: '02'
  };
  let die_03 = {
    pos: [ 1, 1 ],
    vel: [ 5, 3 ],
    startPos: [ 1, 1 ],
    range: 100,
    element: '03'
  };
  let die_04 = {
    pos: [ 1, 1 ],
    vel: [ 2, 2 ],
    startPos: [ 1, 1 ],
    range: 120,
    element: '04'
  };
  let die_05 = {
    pos: [ 1, 1 ],
    vel: [ 5, 5 ],
    startPos: [ 1, 1 ],
    range: 210,
    element: '05'
  };
//
let animationDiceHandler;

startBtn.addEventListener('click', startSpin );

function startSpin(){
    animationDiceHandler = requestAnimationFrame( rotateYoYoMa );
    startBtn.removeEventListener('click', startSpin );
}
let timeoutHandler2;
let reverse = false;


let d =1;
array = ['01','02','03','04','05','06'];
function rotateYoYoMa(){
    if(reverse === false){
        currentImage++;
        d+=2;
        if(currentImage >249){
            currentImage = 1;
        }
        array.forEach(element => {
            $(`#die${element}`).attr('src', `images/rolling-die/dice_animation_${currentImage}.png`);
        });
    }else if(reverse === true){
        currentImage--;
        d+=2;
        if(currentImage < 1){
            currentImage = 250;
            }
            array.forEach(element => {
                $(`#die${element}]`).attr('src', `images/rolling-die/dice_animation_${currentImage}.png`);
            });
        }
    
    timeoutHandler2 = setTimeout(function(){
        animationDiceHandler = requestAnimationFrame( rotateYoYoMa );
    },0.01*d);
}
stopBtn.addEventListener('click', function() {
    cancelAnimationFrame( animationDiceHandler );
    clearTimeout( timeoutHandler2);
    startBtn.addEventListener('click', startSpin );
    
});
/////////// adding my dice object array here
  let rollHandler;
//
let reset = ({ startMs, range, vel, ang=0.95 }) => {
  

    let [ velX, velY ] = [ Math.sin(ang) * vel, Math.cos(ang) * vel ];
  
    
  
    die_01.pos = [ 0, 0 ];
    die_01.vel = [ velX, velY ];
    die_01.startPos = [ 0, 0 ];
    die_01.range = range;
    diceMove.style.left = `${die_01.pos[0]}%`;
    diceMove.style.top = `${die_01.pos[1]}%`;
  };





startBtn.addEventListener('click', startRoll);


function startRoll(){
    rollHandler = requestAnimationFrame( roll );
    startBtn.removeEventListener('click', startRoll );
};
  

let diceMove = die; 

let ms = performance.now();

let timeoutHandler3;
function roll(){
        let diceMove = die; 
    let size = 8;
    let element= die_01.element;
    let ms = performance.now();
    let prevFrame = ms;
    let dms = (ms = 1.2*performance.now()) - prevFrame;
    let dt = dms * 0.001;
    let velMag = Math.hypot(die_01.vel[0], die_01.vel[1]);
    let dx = die_01.pos[0] - die_01.startPos[0];
    let dy = die_01.pos[1] - die_01.startPos[1];
    let rangeRemaining = die_01.range - Math.hypot(dx, dy);
    let velMult = 1 - Math.max(0, Math.min(1, dt * velMag / rangeRemaining));
    if(moveRight === true){ 
        size-=2;
        if(size < 5){
            size = 8;
        }
        die_01.vel[0] *= velMult;
        die_01.vel[1] *= velMult;
        die_01.pos[0] += (die_01.vel[0] * dt);
        die_01.pos[1] += (die_01.vel[1] * dt);
        currentImage++;
        if(currentImage >249){
            currentImage = 1;
        }
        if(die_01.pos[0] > 60){
            moveRight = false;
            diceMove.style.transform = 'scaleX(-1)';
        }
        diceMove.style.left = `${die_01.pos[0]}%`;
        diceMove.style.top = `${die_01.pos[1]}%`;
    }else if(moveRight === false){ 
        die_01.vel[0] *= velMult;
        die_01.vel[1] *= velMult;
        die_01.pos[0] = die_01.pos[0]- die_01.vel[0] * dt;
        die_01.pos[1] = die_01.pos[1]- die_01.vel[1] * dt;
        if(die_01.pos[0] <= 25){
            moveRight = true;
            diceMove.style.transform = 'scaleX(1)';
        }
        die.style.left = `${die_01.pos[0]}%`;
        die.style.top = `${die_01.pos[1]}%`;
    }
    timeoutHandler3 = setTimeout(function(){
    rollHandler = requestAnimationFrame( roll );
    if (moveRight === false && die_01.pos[0] < 57){
    //if (moveRight === false && die_01.pos[0] < 57){//add in velMag
        let element=`01`;
        cancelAnimationFrame(rollHandler);
        cancelAnimationFrame( animationDiceHandler );
        clearTimeout( timeoutHandler2);
        clearTimeout( timeoutHandler3);
        $(`#die${element}`).attr('src', `images/final-die/1.png`);
    }
    });
}

stopBtn.addEventListener('click', function(){
    cancelAnimationFrame(rollHandler);
    clearTimeout( timeoutHandler3);
    startBtn.addEventListener('click', startRoll );

    
});

//////
reverseBtn.addEventListener('click', function(){
    startBtn.addEventListener('click', startRoll );
    reset({
        startMs: ms,
        range: 800,
        vel: 2000,
        ang: 0.95
      });
    
});

//////




let rollHandler2;



function startRoll2(){
    rollHandler2 = requestAnimationFrame( roll2 );
    startBtn.removeEventListener('click', function() {
    })
};
  





let timeoutHandler4;
function roll2(){
    let diceMove = die2; 
    let element= die_02.element;
    let ms = performance.now();
    let prevFrame = ms;
    let dms = (ms = 1.03*performance.now()) - prevFrame;
    let dt = dms * 0.001;
    let velMag = Math.hypot(die_02.vel[0], die_02.vel[1]);
    let dx = die_02.pos[0] - die_02.startPos[0];
    let dy = die_02.pos[1] - die_02.startPos[1];
    if(moveRight === true){ 
        let rangeRemaining = die_02.range - Math.hypot(dx, dy);
        let velMult = 1 - Math.max(0, Math.min(1, dt * velMag / rangeRemaining));
        currentImage++;
        if(currentImage >249){
            currentImage = 1;
        }
         $(`#die${element}`).attr('src', `images/rolling-die/dice_animation_${currentImage}.png`);
        die_02.vel[0] *= velMult;
        die_02.vel[1] *= velMult;
        die_02.pos[0] += (die_02.vel[0] * dt) *2;
        die_02.pos[1] += (die_02.vel[1] * dt) *2;
        if(die_02.pos[0] > 67){
            moveRight = false;
            diceMove.style.transform = 'scaleX(-1)';
        }
        diceMove.style.left = `${die_02.pos[0]}%`;
        diceMove.style.top = `${die_02.pos[1]}%`;
    }else if(moveRight === false){
        currentImage--;
        if(currentImage < 1){
        currentImage = 250;
        }
        let dx = die_02.startPos[0] + die_02.pos[0];
        let dy = die_02.startPos[1] + die_02.pos[1];
        let rangeRemaining = die_02.range - Math.hypot(dx, dy);
        let velMult = 1 - Math.max(0, Math.min(1, dt * velMag / rangeRemaining));
        die_02.vel[0] *= velMult;
        die_02.vel[1] *= velMult;
        die_02.pos[0] = die_02.pos[0] - (die_02.vel[0] * dt);
        die_02.pos[1] = die_02.pos[1] - (die_02.vel[1] * dt);
        die2.style.left = `${die_02.pos[0]}%`;
        die2.style.top = `${die_02.pos[1]}%`;
        $(`#die${element}`).attr('src', `images/rolling-die/dice_animation_${currentImage}.png`);
        if(die_02.pos[0] === die_02.startPos[0]){
            moveRight = true;
            diceMove.style.transform = 'scaleX(1)';
        }
        if(moveRight === false && die_02.pos[0] >20){
            cancelAnimationFrame(rollHandler2);
            let theDie = new Dice();
            theDie.shake();
            let currentImage = theDie.result();
            $(`#die${element}`).attr('src', `images/final-die/${currentImage}.png`);
            return;
            
        }
    }
    timeoutHandler4 = setTimeout(function(){
        rollHandler2 = requestAnimationFrame( roll2 );
    });
}

stopBtn.addEventListener('click', function(){
    startBtn.removeEventListener('click', startRoll2 );
    clearTimeout( timeoutHandler4);
    cancelAnimationFrame(rollHandler2);
    let die_02 = {
        pos: [ 0, 0 ],
        vel: [ 4, 2 ],
        startPos: [ 0, 0 ],
        range: 80,
        element: '02'
      };
      let element= die_02.element;
      die2.style.left = `${die_02.pos[0]}%`;
      die2.style.top = `${die_02.pos[1]}%`;
      moveRight = true;
    $(`#die${element}`).attr('src', `images/rolling-die/dice_animation_${currentImage}.png`);
    startBtn.addEventListener('click', startRoll2 );
});
//////
class Dice{
    constructor(){
        this.dice = [1, 2, 3, 4, 5, 6,];
    }
}

Dice.prototype.result = function(){
    const curDice = this.dice.shift();
    //if we have run out of cards...
    if(curDice === undefined){
        return 'No more ';
    }else{
        //return the next card in the array
        return curDice;
    }         
}
Dice.prototype.shake = function(){
 
    let i, j, k;
    for (i = this.dice.length - 1; i > 0; i--) {
        j = Math.floor(Math.random() * (i + 1));
        k = this.dice[i];
        this.dice[i] = this.dice[j];
        this.dice[j] = k;
    }
    return this.dice;       
}
Dice.prototype.jingoJango = function(){
    let dice1;
    do{
    dice1 = new Dice();
    }while(dice1 == new Dice());
    dice1.shake();
    currentImage = dice1.result();
    return currentImage;
};
let rollHandler3;





function startRoll3(){
    rollHandler3 = requestAnimationFrame( roll3 );
    startBtn.removeEventListener('click', function() {
    })
};
  


////



let timeoutHandler5;
function roll3(){
    let diceMove = die3; 
    let size = 8;
    let element= die_03.element;
    let ms = performance.now();
    let prevFrame = ms;
    let dms = (ms = 1.03*performance.now()) - prevFrame;
    let dt = dms * 0.001;
    let velMag = Math.hypot(die_03.vel[0], die_03.vel[1]);
    let dx = die_03.pos[0] - die_03.startPos[0];
    let dy = die_03.pos[1] - die_03.startPos[1];
    if(moveRight === true){ 
        size-=2;
        if(size < 5){
            size = 8;
        }
        let rangeRemaining = die_03.range - Math.hypot(dx, dy);
        let velMult = 1 - Math.max(0, Math.min(1, dt * velMag / rangeRemaining));
        currentImage++;
        if(currentImage >249){
            currentImage = 1;
        }
         $(`#die${element}`).attr('src', `images/rolling-die/dice_animation_${currentImage}.png`);
        die_03.vel[0] *= velMult;
        die_03.vel[1] *= velMult;
        die_03.pos[0] += (die_03.vel[0] * dt) *2;
        die_03.pos[1] += (die_03.vel[1] * dt) *2;
        if(die_03.pos[0] > 87){
            moveRight = false;
            diceMove.style.transform = 'scaleX(-1)';
        }
        diceMove.style.left = `${die_03.pos[0]}%`;
        diceMove.style.top = `${die_03.pos[1]}%`;
        diceMove.style.width = `${size}%`;
    }else if(moveRight === false){
        currentImage--;
        if(currentImage < 1){
        currentImage = 250;
        }
        let dx = die_03.startPos[0] - die_03.pos[0];
        let dy = die_03.startPos[1] - die_03.pos[1];
        let rangeRemaining = die_03.range - Math.hypot(dx, dy);
        let velMult = 1 - Math.max(0, Math.min(1, dt * velMag / rangeRemaining));
        die_03.vel[0] *= velMult;
        die_03.vel[1] *= velMult;
        die_03.pos[0] = die_03.pos[0] - (die_03.vel[0] * dt);
        die_03.pos[1] = die_03.pos[1] - (die_03.vel[1] * dt);
        die3.style.left = `${die_03.pos[0]}%`;
        die3.style.top = `${die_03.pos[1]}%`;
        $(`#die${element}`).attr('src', `images/rolling-die/dice_animation_${currentImage}.png`);
        if(die_03.pos[0] === die_03.startPos[0]){
            moveRight = true;
            diceMove.style.transform = 'scaleX(1)';
        }
        if(moveRight === false && die_03.pos[0] >90 || moveRight === false && die_03.pos[0] < 77){
            cancelAnimationFrame(rollHandler3);
            let theDie = new Dice();
            theDie.shake();
            let currentImage = theDie.result();
            size=5;
            diceMove.style.width = `${size}%`;
            $(`#die${element}`).attr('src', `images/final-die/${currentImage}.png`);
            return;
            
        }
    }
    timeoutHandler5 = setTimeout(function(){
        rollHandler3 = requestAnimationFrame( roll3 );
    },0.5*size/5);
}

stopBtn.addEventListener('click', function(){
    startBtn.removeEventListener('click', startRoll3 );
    clearTimeout( timeoutHandler5);
    cancelAnimationFrame(rollHandler3);
    let die_03 = {
        pos: [ 1, 1 ],
        vel: [ 5, 3 ],
        startPos: [ 1, 1 ],
        range: 100,
        element: '03'
      };
      let element= die_03.element;
      die3.style.left = `${die_03.pos[0]}%`;
      die3.style.top = `${die_03.pos[1]}%`;
      moveRight = true;
    $(`#die${element}`).attr('src', `images/rolling-die/dice_animation_${currentImage}.png`);
    startBtn.addEventListener('click', startRoll3 );
});
//////
let rollHandler4;





function startRoll4(){
    rollHandler = requestAnimationFrame( roll4 );
    startBtn.removeEventListener('click', function() {
    })
};
  


////
let timeoutHandler6;
function roll4(){
    let diceMove = die4; 
    let size = 8;
    let element= die_04.element;
    let ms = performance.now();
    let prevFrame = ms;
    let dms = (ms = 1.03*performance.now()) - prevFrame;
    let dt = dms * 0.001;
    let velMag = Math.hypot(die_04.vel[0], die_04.vel[1]);
    let dx = die_04.pos[0] - die_04.startPos[0];
    let dy = die_04.pos[1] - die_04.startPos[1];
    if(moveRight === true){ 
        size-=2;
        if(size < 5){
            size = 8;
        }
        let rangeRemaining = die_04.range - Math.hypot(dx, dy);
        let velMult = 1 - Math.max(0, Math.min(1, dt * velMag / rangeRemaining));
        currentImage--;
        if(currentImage >249){
            currentImage = 1;
        }
         $(`#die${element}`).attr('src', `images/rolling-die/dice_animation_${currentImage}.png`);
        die_04.vel[0] *= velMult;
        die_04.vel[1] *= velMult;
        die_04.pos[0] += (die_04.vel[0] * dt) *2;
        die_04.pos[1] += (die_04.vel[1] * dt) *2;
        if(die_04.pos[0] > 107){
            moveRight = false;
            diceMove.style.transform = 'scaleX(-1)';
        }
        diceMove.style.left = `${die_04.pos[0]}%`;
        diceMove.style.top = `${die_04.pos[1]}%`;
        diceMove.style.width = `${size}%`;
    }else if(moveRight === false){
        currentImage--;
        if(currentImage < 1){
        currentImage = 250;
        }
        let dx = die_04.startPos[0] - die_04.pos[0];
        let dy = die_04.startPos[1] - die_04.pos[1];
        let rangeRemaining = die_04.range - Math.hypot(dx, dy);
        let velMult = 1 - Math.max(0, Math.min(1, dt * velMag / rangeRemaining));
        die_04.vel[0] *= velMult;
        die_04.vel[1] *= velMult;
        die_04.pos[0] = die_04.pos[0] - (die_04.vel[0] * dt);
        die_04.pos[1] = die_04.pos[1] - (die_04.vel[1] * dt);
        die4.style.left = `${die_04.pos[0]}%`;
        die4.style.top = `${die_04.pos[1]}%`;
        $(`#die${element}`).attr('src', `images/rolling-die/dice_animation_${currentImage}.png`);
        if(die_04.pos[0] === die_04.startPos[0]){
            moveRight = true;
            diceMove.style.transform = 'scaleX(1)';
        }
        if(moveRight === false && die_04.pos[0] >90 || moveRight === false && die_04.pos[0] < 77){
            cancelAnimationFrame(rollHandler4);
            let theDie = new Dice();
            theDie.shake();
            let currentImage = theDie.result();
            size=5;
            diceMove.style.width = `${size}%`;
            $(`#die${element}`).attr('src', `images/final-die/${currentImage}.png`);
            return;
            
        }
    }
    timeoutHandler6 = setTimeout(function(){
        rollHandler4 = requestAnimationFrame( roll4 );
    },0.5*size/5);
}

stopBtn.addEventListener('click', function(){
    startBtn.removeEventListener('click', startRoll4 );
    clearTimeout( timeoutHandler6);
    cancelAnimationFrame(rollHandler4);
    let die_04 = {
        pos: [ 1, 1 ],
        vel: [ 2, 2 ],
        startPos: [ 1, 1 ],
        range: 140,
        element: '04'
      };
      let element= die_04.element;
      die4.style.left = `${die_04.pos[0]}%`;
      die4.style.top = `${die_04.pos[1]}%`;
      moveRight = true;
    $(`#die${element}`).attr('src', `images/rolling-die/dice_animation_${currentImage}.png`);
    startBtn.addEventListener('click', startRoll4 );
});
  /////
  //////
let rollHandler5;

startBtn.addEventListener('click', function(){
    startRoll();
    startRoll2();
    startRoll5();
    startRoll4();
    startRoll3();
}); 



function startRoll5(){
    rollHandler = requestAnimationFrame( roll5 );
    startBtn.removeEventListener('click', function() {
    })
};
  


////
let timeoutHandler7;
function roll5(){
    let diceMove = die5; 
    let size = 8;
    let element= die_05.element;
    let ms = performance.now();
    let prevFrame = ms;
    let dms = (ms = 1.03*performance.now()) - prevFrame;
    let dt = dms * 0.001;
    let velMag = Math.hypot(die_05.vel[0], die_04.vel[1]);
    let dx = die_05.pos[0] - die_05.startPos[0];
    let dy = die_05.pos[1] - die_05.startPos[1];
    if(moveRight === true){ 
        size-=2;
        if(size < 5){
            size = 8;
        }
        let rangeRemaining = die_05.range - Math.hypot(dx, dy);
        let velMult = 1 - Math.max(0, Math.min(1, dt * velMag / rangeRemaining));
        currentImage++;
        if(currentImage >249){
            currentImage = 1;
        }
         $(`#die${element}`).attr('src', `images/rolling-die/dice_animation_${currentImage}.png`);
        die_05.vel[0] *= velMult;
        die_05.vel[1] *= velMult;
        die_05.pos[0] += (die_05.vel[0] * dt);
        die_05.pos[1] += (die_05.vel[1] * dt);
        if(die_05.pos[0] > 210){
            moveRight = false;
            diceMove.style.transform = 'scaleX(-1)';
        }
        diceMove.style.left = `${die_05.pos[0]}%`;
        diceMove.style.top = `${die_05.pos[1]}%`;
        diceMove.style.width = `${size}%`;
    }else if(moveRight === false){
        currentImage--;
        if(currentImage < 1){
        currentImage = 250;
        }
        let dx = die_05.startPos[0] - die_05.pos[0];
        let dy = die_05.startPos[1] - die_05.pos[1];
        let rangeRemaining = die_05.range - Math.hypot(dx, dy);
        let velMult = 1 - Math.max(0, Math.min(1, dt * velMag / rangeRemaining));
        die_05.vel[0] *= velMult;
        die_05.vel[1] *= velMult;
        die_05.pos[0] -= (die_05.vel[0] * dt);
        die_05.pos[1] -= (die_05.vel[1] * dt);
        die5.style.left = `${die_05.pos[0]}%`;
        die5.style.top = `${die_05.pos[1]}%`;
        $(`#die${element}`).attr('src', `images/rolling-die/dice_animation_${currentImage}.png`);
        if(die_05.pos[0] === die_05.startPos[0]){
            moveRight = true;
            diceMove.style.transform = 'scaleX(1)';
        }
        if(moveRight === false && die_05.pos[0] >300 || moveRight === false && die_05.pos[0] < 67){
            cancelAnimationFrame(rollHandler5);
            let theDie = new Dice();
            theDie.shake();
            let currentImage = theDie.result();
            size=5;
            diceMove.style.width = `${size}%`;
            $(`#die${element}`).attr('src', `images/final-die/${currentImage}.png`);
            return;
            
        }
    }
    timeoutHandler7 = setTimeout(function(){
        rollHandler5 = requestAnimationFrame( roll5 );
    },0.5*size/5);
}

stopBtn.addEventListener('click', function(){
    startBtn.removeEventListener('click', startRoll5 );
    clearTimeout( timeoutHandler7);
    cancelAnimationFrame(rollHandler5);
    let die_05 = {
        pos: [ 1, 1 ],
        vel: [ 2, 2 ],
        startPos: [ 1, 1 ],
        range: 140,
        element: '04'
      };
      let element= die_05.element;
      die5.style.left = `${die_05.pos[0]}%`;
      die5.style.top = `${die_05.pos[1]}%`;
      moveRight = true;
    $(`#die${element}`).attr('src', `images/rolling-die/dice_animation_${currentImage}.png`);
    startBtn.addEventListener('click', startRoll5 );
});
  